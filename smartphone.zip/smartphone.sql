-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: smartphone
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `apple`
--

DROP TABLE IF EXISTS `apple`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `apple` (
  `id` varchar(10) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `size` varchar(20) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `apple`
--

LOCK TABLES `apple` WRITE;
/*!40000 ALTER TABLE `apple` DISABLE KEYS */;
INSERT INTO `apple` VALUES ('A0001','iPhone SE (2022)','Apple','4.7 Inch',15900),('A0002','iPhone 13 Pro Max','Apple','6.7 Inch',42900),('A0003','iPhone 13 Pro','Apple','6.1 Inch',38900),('A0004','iPhone 13','Apple','6.1 Inch',29900),('A0005','iPhone 13 mini','Apple','5.4 Inch',25900),('A0006','iPad Pro 12.9 (2021)','Apple','12.9 Inch',37900),('A0007','iPad Pro 11 (2021)','Apple','11 Inch',27900),('A0008','iPad Air (5th generation)','Apple','10.9 Inch',20900),('A0009','iPad mini (2021)','Apple','8.3 Inch',17900),('A0010','iPad 10.2 (2021)','Apple','10.2 Inch',11400),('A0002','iPhone 13 Pro Max','Apple','6.7 Inch',42900);
/*!40000 ALTER TABLE `apple` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` varchar(10) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `size` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES ('A0002','iPhone 13 Pro Max','Apple','6.7 Inch',42900),('H0001','P50 Pocket','Huawei','6.9 Inch',46990);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `huawei`
--

DROP TABLE IF EXISTS `huawei`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `huawei` (
  `id` varchar(10) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `size` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `huawei`
--

LOCK TABLES `huawei` WRITE;
/*!40000 ALTER TABLE `huawei` DISABLE KEYS */;
INSERT INTO `huawei` VALUES ('H0001','P50 Pocket','Huawei','6.9 Inch',46990),('H0002','P50 Pro','Huawei','6.6 Inch',33990),('H0003','nova 9 SE','Huawei','6.78 Inch',9490),('H0004','MatePad Pro 12.6','Huawei','12.6 Inch',28990),('H0005','MatePad Pro 10.8','Huawei','10.8 Inch',26990),('H0006','nova 9','Huawei','6.57 Inch',16990),('H0007','MatePad 11','Huawei','10.95 Inch',15990),('H0008','MatePad(2021)','Huawei','10.4 Inch',9990),('H0009','nova 8i','Huawei','6.67 Inch',9900),('H0010','Mate Xs','Huawei','8 Inch',89990);
/*!40000 ALTER TABLE `huawei` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idinvoice_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,89890);
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `telephone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idmember_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'Admin','Admin','1234567890','Admin.com','Admin'),(2,'TestFirstName','TestLastName','1234567890','usertest@gmail.com','usertest');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `samsung`
--

DROP TABLE IF EXISTS `samsung`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `samsung` (
  `id` varchar(10) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `size` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `samsung`
--

LOCK TABLES `samsung` WRITE;
/*!40000 ALTER TABLE `samsung` DISABLE KEYS */;
INSERT INTO `samsung` VALUES ('S0001','Galaxy A13','Samsung','6.6 Inch',6499),('S0002','Galaxy A23','Samsung','6.6 Inch',7999),('S0003','Galaxy A73 5G','Samsung','6.7 Inch',17999),('S0004','Galaxy Tab S8 Ultra','Samsung','14.6 Inch',38900),('S0005','Galaxy A53 5G','Samsung','6.5 Inch',14499),('S0006','Galaxy M33','Samsung','6.4 Inch',10990),('S0007','Galaxy M23','Samsung','6.6 Inch',8999),('S0008','Galaxy Tab S8 Plus','Samsung','12.4 Inch',31900),('S0009','Galaxy Tab S8','Samsung','11 Inch',23900),('S0010','Galaxy S22 Ultra','Samsung','6.8 Inch',39900);
/*!40000 ALTER TABLE `samsung` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `xiaomi`
--

DROP TABLE IF EXISTS `xiaomi`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `xiaomi` (
  `id` varchar(10) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `size` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `xiaomi`
--

LOCK TABLES `xiaomi` WRITE;
/*!40000 ALTER TABLE `xiaomi` DISABLE KEYS */;
INSERT INTO `xiaomi` VALUES ('X0001','12 Pro','Xiaomi','6.73 Inch',31990),('X0002','12','Xiaomi','6.28 Inch',24990),('X0003','Black Shark 4 Pro','Xiaomi','6.67 Inch',21990),('X0004','Pad 5','Xiaomi','11 Inch',10900),('X0005','11T','Xiaomi','6.67 Inch',13990),('X0006','11 Lite 5G NE','Xiaomi','6.55 Inch',10990),('X0007','11T Pro','Xiaomi','6.67 Inch',16990),('X0008','Mi 11 Ultra','Xiaomi','6.81 Inch',33990),('X0009','Black Shark 4','Xiaomi','6.67 Inch',16990),('X0010','Mi 11 Pro','Xiaomi','6.81 Inch',26000);
/*!40000 ALTER TABLE `xiaomi` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-24  3:06:49
