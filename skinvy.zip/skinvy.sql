-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: skinvy
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `acne`
--

DROP TABLE IF EXISTS `acne`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `acne` (
  `id` varchar(45) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `acne`
--

LOCK TABLES `acne` WRITE;
/*!40000 ALTER TABLE `acne` DISABLE KEYS */;
INSERT INTO `acne` VALUES ('A0001','Eucerin Pro Acne Solution Anti Acne Mark Serum 40ml','Eucerin',960),('A0002','Eucerin Pro Acne AI Matt Fluid 50ml','Eucerin',891),('A0003','Eucerin Pro Acne Solution A.I. Clearing Treatment 40ml','Eucerin',990),('A0004','Puricas Dragon’s Blood Scar Gel 20g','Puricas',690),('A0005','Peurri Rapid All Acne Clear Gel 8g','Peurri',229),('A0006','Lion Pair Acne Cream W 14g','Lion',370),('A0007','Mederma Intense Gel 20g','Mederma',720);
/*!40000 ALTER TABLE `acne` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cart` (
  `id` varchar(45) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES ('S0005','IPSA Protector Sun Shield SPF50+ PA++++ 30ml','IPSA',690),('C0003','Sulwhasoo Gentle Cleansing Foam 200ml','Sulwhasoo',1125);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cleansing`
--

DROP TABLE IF EXISTS `cleansing`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cleansing` (
  `id` varchar(45) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cleansing`
--

LOCK TABLES `cleansing` WRITE;
/*!40000 ALTER TABLE `cleansing` DISABLE KEYS */;
INSERT INTO `cleansing` VALUES ('C0001','DHC Deep Cleansing Oil 200ml','DHC',799),('C0002','Eucerin Spotless Brightening Cleansing Foam 50g','Eucerin',320),('C0003','Sulwhasoo Gentle Cleansing Foam 200ml','Sulwhasoo',1125),('C0004','ANUA Heartleaf Acne Facial Cleanser 120ml','ANUA',320),('C0005','Eucerin Pro Acne Solution Cleansing Gel 200ml','Eucerin',630),('C0006','Hada Labo Premium Micellar Cleansing Water Hydrating 310ml','Hada Labo',295),('C0007','Purito From Green Cleansing Oil 200ml','Purito',670);
/*!40000 ALTER TABLE `cleansing` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `invoice`
--

DROP TABLE IF EXISTS `invoice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `invoice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `price` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `invoice`
--

LOCK TABLES `invoice` WRITE;
/*!40000 ALTER TABLE `invoice` DISABLE KEYS */;
INSERT INTO `invoice` VALUES (1,1815);
/*!40000 ALTER TABLE `invoice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member` (
  `id` int NOT NULL AUTO_INCREMENT,
  `firstname` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `telephone` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `idmember_UNIQUE` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (1,'Admin','Skinvy','0987654123','admin@skinvy.com','admin'),(2,'skinvy','beauty','0981234560','skinvytest@gmail.com','12345');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sunscreen`
--

DROP TABLE IF EXISTS `sunscreen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sunscreen` (
  `id` varchar(45) NOT NULL,
  `name` varchar(80) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `price` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sunscreen`
--

LOCK TABLES `sunscreen` WRITE;
/*!40000 ALTER TABLE `sunscreen` DISABLE KEYS */;
INSERT INTO `sunscreen` VALUES ('S0001','Mizumi UV Water Serum SPF50+/PA++++ 40g','Mizumi',890),('S0002','Mizumi UV Water Defense Pro 40g','Mizumi',890),('S0003','Venita Anti-Acne Care Sunscreen SPF50/PA+++ 30ml','Venita',490),('S0004','Anessa Perfect UV Sunscreen Skincare Milk N SPF50+/PA++++ 60ml','Anessa',875),('S0005','IPSA Protector Sun Shield SPF50+ PA++++ 30ml','IPSA',690),('S0006','Kindness Freedom Invisible Water Fresh SPF50+/PA++++ 30ml','Kindness',550),('S0007','L\'Oréal Paris UV Defender SPF50+/PA+++ Long UVA Bright & Clear 50ml','L\'Oréal',439);
/*!40000 ALTER TABLE `sunscreen` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-02  5:10:41
